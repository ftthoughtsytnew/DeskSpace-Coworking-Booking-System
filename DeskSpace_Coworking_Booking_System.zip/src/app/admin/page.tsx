import { CalendarCheck, Users, Armchair, IndianRupee, Settings, FileText } from "lucide-react";

const metrics = [
  { label: "Total seats", value: "50", icon: Armchair },
  { label: "Today's bookings", value: "—", icon: CalendarCheck },
  { label: "Customers", value: "—", icon: Users },
  { label: "Revenue", value: "—", icon: IndianRupee },
];

export default function AdminPage() {
  return <div className="admin-shell">
    <aside className="sidebar"><div className="brand">deskspace.</div><p style={{color:"#aebfb4",fontSize:13}}>ADMIN WORKSPACE</p><a className="active" href="/admin">Overview</a><a href="/#booking">Bookings</a><a href="/#booking">Seat management</a><a href="/#booking">Customers</a><a href="/#booking">Documents</a><a href="/#booking">Settings</a></aside>
    <main className="admin-main">
      <span className="eyebrow">Management</span><h1 style={{fontSize:42}}>Dashboard</h1>
      <p className="muted">Your coworking operations at a glance.</p>
      <div className="kpi-grid">{metrics.map(m=><div className="kpi" key={m.label}><m.icon color="#1d5b46"/><p className="muted" style={{fontSize:13}}>{m.label}</p><strong style={{fontSize:28}}>{m.value}</strong></div>)}</div>
      <div className="booking-panel"><h3>Admin setup required</h3><p className="muted">This dashboard is a starter interface. Connect Supabase authentication, add an admin account and apply the database security policies before using it to manage customer data or bookings.</p><div className="notice"><FileText size={16} style={{display:"inline"}}/> Never expose private customer documents or administrative credentials in a public repository.</div></div>
    </main>
  </div>;
}
