import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DeskSpace | Coworking, made simple",
  description: "Find and book a coworking seat in Delhi NCR.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
