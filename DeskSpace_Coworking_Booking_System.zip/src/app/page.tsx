"use client";

import { useMemo, useState } from "react";
import { ArrowRight, Armchair, CalendarDays, Clock3, Coffee, Wifi, ShieldCheck, MapPin, CheckCircle2 } from "lucide-react";
import { isSupabaseConfigured, supabase } from "@/lib/supabase";

type BookingResult = { booking_id: string; booking_code: string; status: string };

export default function Home() {
  const [date, setDate] = useState("");
  const [duration, setDuration] = useState("daily");
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("18:00");
  const [seat, setSeat] = useState<number | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [payment, setPayment] = useState("pay_at_office");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<BookingResult | null>(null);

  const seats = useMemo(() => Array.from({ length: 50 }, (_, i) => i + 1), []);
  const minDate = new Date().toISOString().slice(0, 10);

  async function submitBooking(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMessage("");
    setResult(null);
    if (!supabase) {
      setMessage("Booking is not live yet. Connect your Supabase project and run the SQL setup in supabase/schema.sql.");
      return;
    }
    if (!seat || !date) {
      setMessage("Please select a date and an available seat.");
      return;
    }
    if (duration === "hourly" && endTime <= startTime) {
      setMessage("End time must be later than start time.");
      return;
    }
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("create_public_booking", {
        p_customer_name: name.trim(),
        p_email: email.trim().toLowerCase(),
        p_phone: phone.trim(),
        p_seat_number: seat,
        p_booking_date: date,
        p_duration_type: duration,
        p_start_time: duration === "hourly" ? startTime : null,
        p_end_time: duration === "hourly" ? endTime : null,
        p_payment_method: payment
      });
      if (error) throw error;
      const booking = data as BookingResult;
      setResult(booking);
      setMessage("Your booking request has been recorded. Follow the payment instructions from the coworking team.");
      setSeat(null);
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Could not create booking. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <header className="container nav">
        <a className="brand" href="#">desk<span>space.</span></a>
        <nav className="navlinks"><a href="#workspace">Workspace</a><a href="#amenities">Amenities</a><a href="#booking">Book a seat</a></nav>
        <a className="btn" href="#booking">Book your seat <ArrowRight size={16} /></a>
      </header>

      <main>
        <section className="container hero">
          <div>
            <span className="eyebrow">Flexible workspace · Delhi NCR</span>
            <h1>Your workday,<br/><span style={{color:"var(--green)"}}>your space.</span></h1>
            <p>A calm, connected coworking space designed for focus. Choose a seat, pick your duration and reserve your place in a few simple steps.</p>
            <a className="btn" href="#booking">Find your seat <ArrowRight size={17}/></a>
            <div className="stats">
              <div className="stat"><strong>50</strong><small>Workstations</small></div>
              <div className="stat"><strong>3 ways</strong><small>To book</small></div>
              <div className="stat"><strong>Flexible</strong><small>Plans</small></div>
            </div>
          </div>
          <div className="hero-image"><div className="image-note">A better place to get things done ✦</div></div>
        </section>

        <section className="section" id="workspace" style={{background:"#eef2eb"}}>
          <div className="container">
            <div className="section-head"><div><span className="eyebrow">Designed for your day</span><h2>Space to focus. Room to grow.</h2><p className="muted">A flexible desk for focused work, collaboration and everything in between.</p></div></div>
            <div className="cards" id="amenities">
              <article className="card"><div className="card-icon"><Wifi/></div><h3>Fast Wi-Fi</h3><p className="muted">Stay connected for calls, research and deep work.</p></article>
              <article className="card"><div className="card-icon"><Coffee/></div><h3>Everyday comfort</h3><p className="muted">A welcoming environment for a productive workday.</p></article>
              <article className="card"><div className="card-icon"><ShieldCheck/></div><h3>Simple booking</h3><p className="muted">Choose your seat and duration before you arrive.</p></article>
            </div>
          </div>
        </section>

        <section className="section container" id="booking">
          <div className="section-head"><div><span className="eyebrow">Reserve your workspace</span><h2>Book a seat</h2><p className="muted">Select your preferred date, duration and seat. Booking availability is validated by the database when connected.</p></div></div>
          <div className="booking-wrap">
            <div className="booking-panel">
              <h3 style={{marginTop:0}}>1. Choose your date and plan</h3>
              <div className="field"><label>Booking date</label><input type="date" min={minDate} value={date} onChange={e=>setDate(e.target.value)} required/></div>
              <div className="field"><label>Duration</label><select value={duration} onChange={e=>setDuration(e.target.value)}><option value="hourly">Hourly</option><option value="daily">Daily</option><option value="monthly">Monthly</option></select></div>
              {duration === "hourly" && <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}><div className="field"><label>Start time</label><input type="time" value={startTime} onChange={e=>setStartTime(e.target.value)}/></div><div className="field"><label>End time</label><input type="time" value={endTime} onChange={e=>setEndTime(e.target.value)}/></div></div>}
              <h3>2. Select a seat</h3>
              <div style={{display:"flex",gap:14,fontSize:12,color:"#68756d"}}><span>🟩 Available</span><span>⬛ Selected</span></div>
              <div className="seats">{seats.map(n=><button type="button" key={n} aria-label={`Seat ${n}`} className={`seat ${seat===n?"selected":""}`} onClick={()=>setSeat(n)}> {n.toString().padStart(2,"0")} </button>)}</div>
              <div className="notice">Seat selection is a visual starting point. Live availability and conflict prevention activate after the Supabase database is configured.</div>
            </div>
            <form className="booking-panel" onSubmit={submitBooking}>
              <h3 style={{marginTop:0}}>3. Your details</h3>
              <div className="field"><label>Full name</label><input required value={name} onChange={e=>setName(e.target.value)} placeholder="Your full name"/></div>
              <div className="field"><label>Email address</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></div>
              <div className="field"><label>Mobile number</label><input required value={phone} onChange={e=>setPhone(e.target.value)} placeholder="+91 98765 43210"/></div>
              <div className="field"><label>Payment preference</label><select value={payment} onChange={e=>setPayment(e.target.value)}><option value="pay_at_office">Pay at office</option><option value="online">Online payment (gateway setup required)</option></select></div>
              <div className="notice">Documents are requested only when your booking type or workspace policy requires them. Do not upload identity documents through an unconfigured form.</div>
              <button className="btn" type="submit" disabled={busy} style={{width:"100%",marginTop:18}}>{busy?"Submitting…":"Continue booking"} <ArrowRight size={16}/></button>
              {!isSupabaseConfigured && <p className="muted" style={{fontSize:12}}>Preview mode: connect Supabase to accept real bookings.</p>}
              {message && <p role="status" className="notice" style={{marginTop:14}}>{message}</p>}
              {result && <div className="notice" style={{marginTop:12}}><strong>Booking ID: {result.booking_code}</strong><br/>Status: {result.status}</div>}
            </form>
          </div>
        </section>
      </main>
      <footer className="footer"><div className="container" style={{display:"flex",justifyContent:"space-between",gap:20,flexWrap:"wrap"}}><div><div className="brand">deskspace.</div><p>Flexible coworking in Delhi NCR.</p></div><div><p><MapPin size={15} style={{display:"inline"}}/> Delhi NCR, India</p><p>Business name and address can be customized before launch.</p></div></div></footer>
    </>
  );
}
